
export OMP_NUM_THREADS=1
./ndshox.sh --seed 210986882 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 210997152 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 2252815688 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 2252849249 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 3262 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 5171 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 5435 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 6523 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 10271 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 10342 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 10869 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 20541 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 33562 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 46404 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 55938 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 61333 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 67123 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 92807 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 111876 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 122665 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 439361 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 878722 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 11998334 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 21281288 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 21284549 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 23996667 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 45961878 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 53488824 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 53493995 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 59078450 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 59083884 --num_gpus 4 --master_port 15432
./ndshox.sh --seed 91923756 --num_gpus 4 --master_port 15432

mail -s "$0 completed" stmille3@ncsu.edu <<EOF

$0 completed

EOF

