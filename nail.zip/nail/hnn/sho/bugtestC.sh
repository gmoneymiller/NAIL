
./ndshox.sh --seed 53493995 --master_port 15432 --num_gpus 0
