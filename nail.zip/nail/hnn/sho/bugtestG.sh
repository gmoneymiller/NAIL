
./ndshox.sh --seed 53493995 --master_port 15433 --num_gpus 4
