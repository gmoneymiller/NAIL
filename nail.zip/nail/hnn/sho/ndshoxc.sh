
python shox.py $@ \
  --activation_fn 'Tanh' \
  --batch_size 1  \
  --dsr 0.1 \
  --early_stop 9e-10 \
  --epochs 16 \
  --hamiltonian="(p**2 + q**2) / 2" \
  --hidden_dim 32 32  \
  --learn_rate 1e-03  \
  --name "sho-dataset-nb2-dsr1e-01-tspan0_100-traj2000" \
  --num_bodies 2 \
  --save_dir 'save' \
  --state_symbols q p \
  --test_pct 1 \
  --train_pct 0 \
  --tspan 0 10 \
  --num_gpus 0
